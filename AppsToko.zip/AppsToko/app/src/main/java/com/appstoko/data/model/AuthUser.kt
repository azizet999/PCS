package com.appstoko.data.model

data class AuthUser(
    val Id: Int = 0,
    val Email : String ="",
    val Password: String="",
    val FullName: String = ""
)
